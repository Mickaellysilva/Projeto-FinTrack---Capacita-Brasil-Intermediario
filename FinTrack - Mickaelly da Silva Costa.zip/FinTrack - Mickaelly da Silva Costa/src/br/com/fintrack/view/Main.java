package br.com.fintrack.view;

import br.com.fintrack.model.*;
import br.com.fintrack.exception.FinancasException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static ArrayList<Transacao> listaTransacoes = new ArrayList<>();
    private static Scanner leitor = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        System.out.println(" BEM-VINDO AO FINTRACK ");

        do {
            try {
                exibirMenu();
                opcao = Integer.parseInt(leitor.nextLine());

                switch (opcao) {
                    case 1 -> cadastrarTransacao(true);  // Receita
                    case 2 -> cadastrarTransacao(false); // Despesa
                    case 3 -> listarExtrato();
                    case 4 -> mostrarSaldo();
                    case 0 -> System.out.println("Sistema finalizado. Até logo!");
                    default -> System.out.println("Opção inválida! Tente novamente.");
                }
            } catch (NumberFormatException e) {
                System.err.println("Erro: Por favor, insira um valor numérico válido.");
            } catch (FinancasException e) {
                System.err.println("Atenção: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Ocorreu um erro inesperado: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static void exibirMenu() {
        System.out.println("1. Lançar Receita (+)");
        System.out.println("2. Lançar Despesa (-)");
        System.out.println("3. Ver Extrato");
        System.out.println("4. Ver Saldo Total");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private static void cadastrarTransacao(boolean ehReceita) throws FinancasException {
        System.out.print("Descrição da operação: ");
        String desc = leitor.nextLine();

        System.out.print("Valor (R$): ");
        double valor = Double.parseDouble(leitor.nextLine());

        if (valor <= 0) {
            throw new FinancasException("O valor da transação deve ser positivo!");
        }

        if (ehReceita) {
            listaTransacoes.add(new Receita(desc, valor));
        } else {
            listaTransacoes.add(new Despesa(desc, valor));
        }
        System.out.println("Lançamento efetuado!");
    }

    private static void listarExtrato() {
        System.out.println("SEU EXTRATO");
        if (listaTransacoes.isEmpty()) {
            System.out.println("Nenhuma movimentação registrada.");
        } else {
            for (Transacao t : listaTransacoes) {
                System.out.println(t);
            }
        }
    }

    private static void mostrarSaldo() {
        double saldoTotal = 0;
        for (Transacao t : listaTransacoes) {
            saldoTotal += t.getValorCalculado();
        }
        System.out.printf(" SALDO ATUAL: R$ %.2f\n", saldoTotal);
        if (saldoTotal < 0) System.out.println("Cuidado! Seu saldo está negativo.");
    }
}