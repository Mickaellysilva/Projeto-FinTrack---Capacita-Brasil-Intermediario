package br.com.fintrack.model;

public class Despesa extends Transacao {
    public Despesa(String desc, double val) { super(desc, val); }
    @Override public String getTipo() { return "DESPESA"; }
    @Override public double getValorCalculado() { return -valor; }
}