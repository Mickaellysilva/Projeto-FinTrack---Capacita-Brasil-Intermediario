package br.com.fintrack.model;

public abstract class Transacao {
    protected String descricao;
    protected double valor;

    public Transacao(String descricao, double valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    public abstract String getTipo();
    public abstract double getValorCalculado(); // Define se soma ou subtrai

    @Override
    public String toString() {
        return String.format("[%s] %s: R$ %.2f", getTipo(), descricao, valor);
    }
}