package br.com.fintrack.model;

public class Receita extends Transacao {
    public Receita(String desc, double val) { super(desc, val); }
    @Override public String getTipo() { return "RECEITA"; }
    @Override public double getValorCalculado() { return valor; }
}
