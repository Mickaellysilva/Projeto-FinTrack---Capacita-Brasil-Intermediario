package br.com.fintrack.service;

import br.com.fintrack.model.Transacao;
import java.util.ArrayList;
import java.util.List;

public class FinancasService {
    private List<Transacao> transacoes = new ArrayList<>();

    public void adicionarTransacao(Transacao t) {
        transacoes.add(t);
    }

    public double calcularSaldo() {
        return transacoes.stream().mapToDouble(Transacao::getValorCalculado).sum();
    }

    public List<Transacao> listarTodas() {
        return new ArrayList<>(transacoes);
    }
}