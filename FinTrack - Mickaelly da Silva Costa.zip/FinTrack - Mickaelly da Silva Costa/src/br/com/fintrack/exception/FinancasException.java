package br.com.fintrack.exception;

public class FinancasException extends Exception {
    public FinancasException(String mensagem) {
        super(mensagem);
    }
}